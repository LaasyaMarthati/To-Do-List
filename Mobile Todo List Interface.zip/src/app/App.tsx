import { useState } from 'react';
import { Todo } from './types/todo';
import { HomePage } from './pages/HomePage';
import { StatsPage } from './pages/StatsPage';
import { SettingsPage } from './pages/SettingsPage';
import { BottomNav } from './components/BottomNav';

type Page = 'home' | 'stats' | 'settings';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [todos, setTodos] = useState<Todo[]>([
    {
      id: '1',
      text: 'Complete project presentation',
      emoji: '💼',
      completed: false,
      priority: 'high',
      time: '14:00',
      date: new Date().toISOString().split('T')[0],
      category: 'Work',
      createdAt: Date.now() - 3600000,
    },
    {
      id: '2',
      text: 'Buy groceries for dinner',
      emoji: '🛒',
      completed: false,
      priority: 'medium',
      time: '18:00',
      date: new Date().toISOString().split('T')[0],
      category: 'Shopping',
      createdAt: Date.now() - 7200000,
    },
    {
      id: '3',
      text: 'Morning workout routine',
      emoji: '💪',
      completed: true,
      priority: 'medium',
      time: '07:00',
      date: new Date().toISOString().split('T')[0],
      category: 'Health',
      createdAt: Date.now() - 10800000,
    },
    {
      id: '4',
      text: 'Read 30 pages of book',
      emoji: '📚',
      completed: false,
      priority: 'low',
      category: 'Personal',
      createdAt: Date.now() - 14400000,
    },
    {
      id: '5',
      text: 'Team meeting preparation',
      emoji: '👥',
      completed: false,
      priority: 'high',
      time: '10:00',
      date: new Date(Date.now() + 86400000).toISOString().split('T')[0],
      category: 'Work',
      createdAt: Date.now() - 18000000,
    },
  ]);

  const addTodo = (task: Omit<Todo, 'id' | 'completed' | 'createdAt'>) => {
    const newTodo: Todo = {
      ...task,
      id: Date.now().toString(),
      completed: false,
      createdAt: Date.now(),
    };
    setTodos([newTodo, ...todos]);
  };

  const toggleTodo = (id: string) => {
    setTodos(
      todos.map((todo) =>
        todo.id === id ? { ...todo, completed: !todo.completed } : todo
      )
    );
  };

  const deleteTodo = (id: string) => {
    setTodos(todos.filter((todo) => todo.id !== id));
  };

  return (
    <div className="min-h-screen bg-white">
      {currentPage === 'home' && (
        <HomePage
          todos={todos}
          onToggle={toggleTodo}
          onDelete={deleteTodo}
          onAdd={addTodo}
          onMenuClick={() => {}}
        />
      )}
      
      {currentPage === 'stats' && <StatsPage todos={todos} />}
      
      {currentPage === 'settings' && <SettingsPage />}

      <BottomNav currentPage={currentPage} onPageChange={setCurrentPage} />
    </div>
  );
}

export default App;
