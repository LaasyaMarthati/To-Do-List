export type Priority = 'low' | 'medium' | 'high';

export interface Todo {
  id: string;
  text: string;
  emoji: string;
  completed: boolean;
  priority: Priority;
  time?: string;
  date?: string;
  category: string;
  createdAt: number;
}

export type FilterType = 'all' | 'active' | 'completed';
export type SortType = 'priority' | 'date' | 'created';
