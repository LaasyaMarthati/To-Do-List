import { ChevronRight } from 'lucide-react';

export function SettingsPage() {
  const settingsItems = [
    { emoji: '🎨', title: 'Appearance', description: 'Theme and colors' },
    { emoji: '🔔', title: 'Notifications', description: 'Manage reminders' },
    { emoji: '📁', title: 'Categories', description: 'Manage task categories' },
    { emoji: '⚙️', title: 'General', description: 'App preferences' },
    { emoji: '📊', title: 'Data & Storage', description: 'Manage your data' },
    { emoji: 'ℹ️', title: 'About', description: 'Version and info' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      <div className="bg-gradient-to-br from-purple-500 to-pink-600 px-6 pt-12 pb-8 rounded-b-3xl">
        <h1 className="text-white mb-2">⚙️ Settings</h1>
        <p className="text-white/80">Customize your experience</p>
      </div>

      <div className="px-6 -mt-6">
        {/* Profile Card */}
        <div className="bg-white rounded-3xl p-6 shadow-sm mb-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-purple-500 rounded-2xl flex items-center justify-center text-2xl">
              👤
            </div>
            <div className="flex-1">
              <h3>User Profile</h3>
              <p className="text-gray-500 text-sm">Manage your account</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </div>
        </div>

        {/* Settings List */}
        <div className="bg-white rounded-3xl shadow-sm overflow-hidden">
          {settingsItems.map((item, index) => (
            <button
              key={item.title}
              className={`w-full flex items-center gap-4 p-5 active:bg-gray-50 transition-colors ${
                index !== settingsItems.length - 1 ? 'border-b border-gray-100' : ''
              }`}
            >
              <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center text-xl">
                {item.emoji}
              </div>
              <div className="flex-1 text-left">
                <div className="text-gray-800">{item.title}</div>
                <p className="text-gray-500 text-sm">{item.description}</p>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
          ))}
        </div>

        {/* App Info */}
        <div className="mt-8 text-center text-gray-400 text-sm">
          <p>Todo App v1.0.0</p>
          <p className="mt-1">Made with ❤️ by Figma Make</p>
        </div>
      </div>
    </div>
  );
}
