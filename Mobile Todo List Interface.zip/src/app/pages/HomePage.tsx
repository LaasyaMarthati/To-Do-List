import { useState, useMemo } from 'react';
import { Plus, Star, Calendar, Menu } from 'lucide-react';
import { Todo, FilterType, SortType } from '../types/todo';
import { TaskItem } from '../components/TaskItem';
import { AddTaskModal } from '../components/AddTaskModal';

interface HomePageProps {
  todos: Todo[];
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onAdd: (task: Omit<Todo, 'id' | 'completed' | 'createdAt'>) => void;
  onMenuClick: () => void;
}

export function HomePage({ todos, onToggle, onDelete, onAdd, onMenuClick }: HomePageProps) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [filter, setFilter] = useState<FilterType>('all');
  const [sort, setSort] = useState<SortType>('priority');

  const todayDate = new Date().toDateString();

  const sortedAndFilteredTodos = useMemo(() => {
    let filtered = [...todos];

    // Apply filter
    if (filter === 'active') {
      filtered = filtered.filter((t) => !t.completed);
    } else if (filter === 'completed') {
      filtered = filtered.filter((t) => t.completed);
    }

    // Apply sort
    filtered.sort((a, b) => {
      // Always put important (high priority) tasks at top
      if (a.priority === 'high' && b.priority !== 'high') return -1;
      if (a.priority !== 'high' && b.priority === 'high') return 1;

      // Then sort by selected criteria
      if (sort === 'priority') {
        const priorityOrder = { high: 3, medium: 2, low: 1 };
        return priorityOrder[b.priority] - priorityOrder[a.priority];
      } else if (sort === 'date') {
        if (!a.date && !b.date) return 0;
        if (!a.date) return 1;
        if (!b.date) return -1;
        return new Date(a.date).getTime() - new Date(b.date).getTime();
      } else {
        return b.createdAt - a.createdAt;
      }
    });

    return filtered;
  }, [todos, filter, sort]);

  const stats = useMemo(() => {
    const total = todos.length;
    const completed = todos.filter((t) => t.completed).length;
    const active = total - completed;
    const todayTasks = todos.filter(
      (t) => t.date && new Date(t.date).toDateString() === todayDate
    ).length;

    return { total, completed, active, todayTasks };
  }, [todos, todayDate]);

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <div className="bg-white px-6 pt-12 pb-6 rounded-b-3xl shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={onMenuClick}
            className="w-10 h-10 flex items-center justify-center rounded-xl active:bg-gray-100"
          >
            <Menu className="w-6 h-6 text-gray-700" />
          </button>
          <h1 className="text-gray-800">✨ My Tasks</h1>
          <button
            onClick={() => setShowAddModal(true)}
            className="w-10 h-10 flex items-center justify-center bg-blue-500 rounded-xl active:bg-blue-600"
          >
            <Plus className="w-6 h-6 text-white" strokeWidth={2.5} />
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-blue-50 rounded-2xl p-4">
            <div className="text-2xl mb-1">📋</div>
            <div className="text-gray-500 text-sm">Total</div>
            <div>{stats.total}</div>
          </div>
          <div className="bg-green-50 rounded-2xl p-4">
            <div className="text-2xl mb-1">✅</div>
            <div className="text-gray-500 text-sm">Done</div>
            <div>{stats.completed}</div>
          </div>
          <div className="bg-purple-50 rounded-2xl p-4">
            <div className="text-2xl mb-1">📆</div>
            <div className="text-gray-500 text-sm">Today</div>
            <div>{stats.todayTasks}</div>
          </div>
        </div>
      </div>

      <div className="px-6 pt-6">
        {/* Filters */}
        <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
          {(['all', 'active', 'completed'] as FilterType[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-full whitespace-nowrap transition-all ${
                filter === f
                  ? 'bg-blue-500 text-white'
                  : 'bg-white text-gray-600 border border-gray-200'
              }`}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>

        {/* Sort */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          <span className="text-gray-500 py-2 pr-2">Sort:</span>
          {(['priority', 'date', 'created'] as SortType[]).map((s) => (
            <button
              key={s}
              onClick={() => setSort(s)}
              className={`px-4 py-2 rounded-full whitespace-nowrap text-sm transition-all ${
                sort === s
                  ? 'bg-gray-800 text-white'
                  : 'bg-white text-gray-600 border border-gray-200'
              }`}
            >
              {s === 'priority' && '⭐ Priority'}
              {s === 'date' && '📅 Date'}
              {s === 'created' && '🕒 Recent'}
            </button>
          ))}
        </div>

        {/* Tasks List */}
        {sortedAndFilteredTodos.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">🎯</div>
            <p className="text-gray-500">No tasks found</p>
            <button
              onClick={() => setShowAddModal(true)}
              className="mt-4 px-6 py-3 bg-blue-500 text-white rounded-full active:bg-blue-600"
            >
              Add your first task
            </button>
          </div>
        ) : (
          <div>
            {sortedAndFilteredTodos.map((todo) => (
              <TaskItem
                key={todo.id}
                todo={todo}
                onToggle={onToggle}
                onDelete={onDelete}
              />
            ))}
          </div>
        )}
      </div>

      {showAddModal && (
        <AddTaskModal onClose={() => setShowAddModal(false)} onAdd={onAdd} />
      )}
    </div>
  );
}
