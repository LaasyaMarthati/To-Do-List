import { useMemo } from 'react';
import { Todo } from '../types/todo';

interface StatsPageProps {
  todos: Todo[];
}

export function StatsPage({ todos }: StatsPageProps) {
  const stats = useMemo(() => {
    const total = todos.length;
    const completed = todos.filter((t) => t.completed).length;
    const active = total - completed;
    const completionRate = total > 0 ? Math.round((completed / total) * 100) : 0;

    // Priority breakdown
    const highPriority = todos.filter((t) => t.priority === 'high' && !t.completed).length;
    const mediumPriority = todos.filter((t) => t.priority === 'medium' && !t.completed).length;
    const lowPriority = todos.filter((t) => t.priority === 'low' && !t.completed).length;

    // Category breakdown
    const categories = todos.reduce((acc, todo) => {
      acc[todo.category] = (acc[todo.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      total,
      completed,
      active,
      completionRate,
      highPriority,
      mediumPriority,
      lowPriority,
      categories,
    };
  }, [todos]);

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      <div className="bg-gradient-to-br from-blue-500 to-purple-600 px-6 pt-12 pb-8 rounded-b-3xl">
        <h1 className="text-white mb-2">📊 Statistics</h1>
        <p className="text-white/80">Your productivity overview</p>
      </div>

      <div className="px-6 -mt-6">
        {/* Completion Rate */}
        <div className="bg-white rounded-3xl p-6 shadow-sm mb-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-gray-500 text-sm">Completion Rate</p>
              <div className="text-3xl">{stats.completionRate}%</div>
            </div>
            <div className="text-5xl">🎯</div>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
            <div
              className="bg-gradient-to-r from-green-400 to-green-600 h-full rounded-full transition-all"
              style={{ width: `${stats.completionRate}%` }}
            />
          </div>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-white rounded-2xl p-5 shadow-sm">
            <div className="text-3xl mb-2">📝</div>
            <p className="text-gray-500 text-sm mb-1">Total Tasks</p>
            <div className="text-2xl">{stats.total}</div>
          </div>

          <div className="bg-white rounded-2xl p-5 shadow-sm">
            <div className="text-3xl mb-2">✅</div>
            <p className="text-gray-500 text-sm mb-1">Completed</p>
            <div className="text-2xl text-green-600">{stats.completed}</div>
          </div>

          <div className="bg-white rounded-2xl p-5 shadow-sm">
            <div className="text-3xl mb-2">⏳</div>
            <p className="text-gray-500 text-sm mb-1">Active</p>
            <div className="text-2xl text-blue-600">{stats.active}</div>
          </div>

          <div className="bg-white rounded-2xl p-5 shadow-sm">
            <div className="text-3xl mb-2">⭐</div>
            <p className="text-gray-500 text-sm mb-1">High Priority</p>
            <div className="text-2xl text-red-600">{stats.highPriority}</div>
          </div>
        </div>

        {/* Priority Breakdown */}
        <div className="bg-white rounded-2xl p-6 shadow-sm mb-4">
          <h3 className="mb-4 flex items-center gap-2">
            <span>🎨</span>
            Priority Breakdown
          </h3>
          
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">High Priority</span>
                <span className="text-red-600">{stats.highPriority}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-red-500 h-full rounded-full"
                  style={{
                    width: `${stats.active > 0 ? (stats.highPriority / stats.active) * 100 : 0}%`,
                  }}
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">Medium Priority</span>
                <span className="text-yellow-600">{stats.mediumPriority}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-yellow-500 h-full rounded-full"
                  style={{
                    width: `${stats.active > 0 ? (stats.mediumPriority / stats.active) * 100 : 0}%`,
                  }}
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">Low Priority</span>
                <span className="text-blue-600">{stats.lowPriority}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-blue-500 h-full rounded-full"
                  style={{
                    width: `${stats.active > 0 ? (stats.lowPriority / stats.active) * 100 : 0}%`,
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Categories */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <h3 className="mb-4 flex items-center gap-2">
            <span>📁</span>
            Categories
          </h3>
          
          <div className="space-y-3">
            {Object.entries(stats.categories).map(([category, count]) => (
              <div key={category} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-0">
                <span className="text-gray-700">{category}</span>
                <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm">
                  {count}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
