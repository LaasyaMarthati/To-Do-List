import { useState } from 'react';
import { X, Calendar, Clock, Star } from 'lucide-react';
import { Priority } from '../types/todo';
import { EmojiPicker } from './EmojiPicker';

interface AddTaskModalProps {
  onClose: () => void;
  onAdd: (task: {
    text: string;
    emoji: string;
    priority: Priority;
    time?: string;
    date?: string;
    category: string;
  }) => void;
}

export function AddTaskModal({ onClose, onAdd }: AddTaskModalProps) {
  const [text, setText] = useState('');
  const [emoji, setEmoji] = useState('📝');
  const [priority, setPriority] = useState<Priority>('medium');
  const [time, setTime] = useState('');
  const [date, setDate] = useState('');
  const [category, setCategory] = useState('Personal');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  const handleSubmit = () => {
    if (!text.trim()) return;

    onAdd({
      text: text.trim(),
      emoji,
      priority,
      time: time || undefined,
      date: date || undefined,
      category,
    });

    onClose();
  };

  const priorities: { value: Priority; label: string; color: string }[] = [
    { value: 'low', label: 'Low', color: 'bg-blue-500' },
    { value: 'medium', label: 'Medium', color: 'bg-yellow-500' },
    { value: 'high', label: 'High', color: 'bg-red-500' },
  ];

  const categories = ['Personal', 'Work', 'Shopping', 'Health', 'Other'];

  return (
    <>
      <div className="fixed inset-0 bg-black/50 z-40 flex items-end">
        <div className="bg-white w-full rounded-t-3xl max-h-[90vh] overflow-y-auto animate-slide-up">
          {/* Header */}
          <div className="sticky top-0 bg-white border-b border-gray-200 p-4 flex items-center justify-between">
            <h2>Add New Task</h2>
            <button
              onClick={onClose}
              className="w-10 h-10 flex items-center justify-center rounded-full active:bg-gray-100"
            >
              <X className="w-6 h-6 text-gray-600" />
            </button>
          </div>

          <div className="p-6 space-y-6">
            {/* Emoji & Title */}
            <div className="flex gap-3">
              <button
                onClick={() => setShowEmojiPicker(true)}
                className="w-16 h-16 flex items-center justify-center bg-gray-100 rounded-2xl active:bg-gray-200"
              >
                <span className="text-3xl">{emoji}</span>
              </button>
              <input
                type="text"
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Task title..."
                className="flex-1 px-4 py-3 border-2 border-gray-200 rounded-2xl focus:outline-none focus:border-blue-500"
                autoFocus
              />
            </div>

            {/* Priority */}
            <div>
              <label className="block mb-3 text-gray-600">Priority</label>
              <div className="flex gap-3">
                {priorities.map((p) => (
                  <button
                    key={p.value}
                    onClick={() => setPriority(p.value)}
                    className={`flex-1 py-3 px-4 rounded-xl border-2 transition-all ${
                      priority === p.value
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-center gap-2">
                      <div className={`w-3 h-3 rounded-full ${p.color}`} />
                      <span>{p.label}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Date */}
            <div>
              <label className="flex items-center gap-2 mb-3 text-gray-600">
                <Calendar className="w-4 h-4" />
                Date
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-2xl focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Time */}
            <div>
              <label className="flex items-center gap-2 mb-3 text-gray-600">
                <Clock className="w-4 h-4" />
                Time
              </label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-2xl focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Category */}
            <div>
              <label className="block mb-3 text-gray-600">Category</label>
              <div className="grid grid-cols-3 gap-3">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setCategory(cat)}
                    className={`py-3 px-4 rounded-xl border-2 transition-all ${
                      category === cat
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 bg-white'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Add Button */}
            <button
              onClick={handleSubmit}
              disabled={!text.trim()}
              className="w-full py-4 bg-blue-500 text-white rounded-2xl disabled:bg-gray-300 disabled:cursor-not-allowed active:bg-blue-600"
            >
              Add Task
            </button>
          </div>
        </div>
      </div>

      {showEmojiPicker && (
        <EmojiPicker
          onEmojiSelect={setEmoji}
          onClose={() => setShowEmojiPicker(false)}
        />
      )}
    </>
  );
}
