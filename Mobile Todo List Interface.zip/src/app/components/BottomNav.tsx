import { Home, Star, Settings } from 'lucide-react';

type Page = 'home' | 'stats' | 'settings';

interface BottomNavProps {
  currentPage: Page;
  onPageChange: (page: Page) => void;
}

export function BottomNav({ currentPage, onPageChange }: BottomNavProps) {
  const navItems: { page: Page; icon: typeof Home; label: string; emoji: string }[] = [
    { page: 'home', icon: Home, label: 'Home', emoji: '🏠' },
    { page: 'stats', icon: Star, label: 'Stats', emoji: '📊' },
    { page: 'settings', icon: Settings, label: 'Settings', emoji: '⚙️' },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 safe-area-bottom">
      <div className="max-w-md mx-auto flex items-center justify-around px-6 py-3">
        {navItems.map(({ page, icon: Icon, label, emoji }) => (
          <button
            key={page}
            onClick={() => onPageChange(page)}
            className={`flex flex-col items-center gap-1 py-2 px-6 rounded-2xl transition-all ${
              currentPage === page ? 'bg-blue-50' : ''
            }`}
          >
            <div
              className={`transition-all ${
                currentPage === page ? 'text-blue-600' : 'text-gray-400'
              }`}
            >
              {currentPage === page ? (
                <span className="text-2xl">{emoji}</span>
              ) : (
                <Icon className="w-6 h-6" />
              )}
            </div>
            <span
              className={`text-xs ${
                currentPage === page ? 'text-blue-600' : 'text-gray-500'
              }`}
            >
              {label}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
