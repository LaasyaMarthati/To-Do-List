import { Check, Circle, Trash2, Star, Calendar, Clock } from 'lucide-react';
import { Todo } from '../types/todo';

interface TaskItemProps {
  todo: Todo;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

export function TaskItem({ todo, onToggle, onDelete }: TaskItemProps) {
  const priorityColors = {
    low: 'bg-blue-500',
    medium: 'bg-yellow-500',
    high: 'bg-red-500',
  };

  return (
    <div className="bg-white rounded-2xl p-4 mb-3 border border-gray-100 active:bg-gray-50">
      <div className="flex items-start gap-3">
        {/* Checkbox */}
        <button
          onClick={() => onToggle(todo.id)}
          className="flex-shrink-0 w-6 h-6 flex items-center justify-center mt-1"
          aria-label={todo.completed ? 'Mark as incomplete' : 'Mark as complete'}
        >
          {todo.completed ? (
            <div className="w-6 h-6 rounded-full bg-green-500 flex items-center justify-center">
              <Check className="w-4 h-4 text-white" strokeWidth={3} />
            </div>
          ) : (
            <Circle className="w-6 h-6 text-gray-300" strokeWidth={2} />
          )}
        </button>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start gap-2 mb-2">
            <span className="text-2xl flex-shrink-0">{todo.emoji}</span>
            <div className="flex-1">
              <p
                className={`${
                  todo.completed ? 'line-through text-gray-400' : 'text-gray-800'
                }`}
              >
                {todo.text}
              </p>
            </div>
          </div>

          {/* Meta info */}
          <div className="flex items-center gap-3 flex-wrap">
            <div className={`w-2 h-2 rounded-full ${priorityColors[todo.priority]}`} />
            
            {todo.date && (
              <div className="flex items-center gap-1 text-gray-500 text-sm">
                <Calendar className="w-3 h-3" />
                <span>{new Date(todo.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
              </div>
            )}
            
            {todo.time && (
              <div className="flex items-center gap-1 text-gray-500 text-sm">
                <Clock className="w-3 h-3" />
                <span>{todo.time}</span>
              </div>
            )}
            
            <span className="text-xs bg-gray-100 px-2 py-1 rounded-full text-gray-600">
              {todo.category}
            </span>
          </div>
        </div>

        {/* Delete Button */}
        <button
          onClick={() => onDelete(todo.id)}
          className="flex-shrink-0 w-10 h-10 flex items-center justify-center text-gray-400 active:text-red-500 rounded-xl active:bg-red-50"
          aria-label="Delete task"
        >
          <Trash2 className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
