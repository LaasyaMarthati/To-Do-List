import { useState } from 'react';
import EmojiPickerReact, { EmojiClickData } from 'emoji-picker-react';
import { X } from 'lucide-react';

interface EmojiPickerProps {
  onEmojiSelect: (emoji: string) => void;
  onClose: () => void;
}

export function EmojiPicker({ onEmojiSelect, onClose }: EmojiPickerProps) {
  const handleEmojiClick = (emojiData: EmojiClickData) => {
    onEmojiSelect(emojiData.emoji);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
      <div className="bg-white w-full rounded-t-3xl animate-slide-up">
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <h3>Choose Emoji</h3>
          <button onClick={onClose} className="p-2 rounded-full active:bg-gray-100">
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>
        <div className="p-4">
          <EmojiPickerReact
            onEmojiClick={handleEmojiClick}
            width="100%"
            height="400px"
            searchPlaceHolder="Search emoji..."
          />
        </div>
      </div>
    </div>
  );
}
