
  # Mobile Todo List Interface

  This is a code bundle for Mobile Todo List Interface. The original project is available at https://www.figma.com/design/ZpfgOz9ScgZK6zCDW9TMYv/Mobile-Todo-List-Interface.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  